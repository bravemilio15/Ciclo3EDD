/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista.arreglos;

import controlador.MarcaController;
import javax.swing.JComboBox;
import modelo.Marca;

/**
 *
 * @author emilio
 */
public class UtilVista {

    public static void cargarMarca(JComboBox cbxMarca) {
        MarcaController mc = new MarcaController();
        cbxMarca.removeAllItems();
        for (int i = 0; i < mc.getMarcas().length; i++) {
            cbxMarca.addItem(mc.getMarcas()[i]);
        }
    }

    public static Marca getComboMarcas(JComboBox cbx) {
        return (Marca) cbx.getSelectedItem();
    }
}
