/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Llanta;

/**
 *
 * @author emilio
 */
public class LlantaController {

    private Llanta[] llantas;
    private Llanta llanta = new Llanta();

    public Llanta getLlanta() {
        if (llanta == null) {
            llanta = new Llanta();
        }
        return llanta;
    }

    public void setLlanta(Llanta llanta) {
        this.llanta = llanta;
    }

    public LlantaController(Integer n) {
        this.llantas = new Llanta[n];
    }

    public Llanta[] getLlantas() {
        return llantas;
    }

    public void setLlantas(Llanta[] llantas) {
        this.llantas = llantas;
    }

    public Boolean guardar() {
        Integer pos = pos_verificar();
        if (pos > -1) {
            llanta.setId(generar_id());
            llantas[pos_verificar()] = llanta;
            //llanta = null;
            return true;
        }

        return false;
    }

    public void Imprimir() {
        for (int i = 0; i < llantas.length; i++) {
            if (llantas[i] != null) {
                System.out.println("id: " + llantas[i].getId() + " Descripcion: " + llantas[i].getDescripcion());
            }
        }
        System.out.println(" ");
    }

    private Integer pos_verificar() {
        for (int i = 0; i < llantas.length; i++) {
            if (llantas[i] == null) {
                return i;
            }
        }
        return -1;
    }

    private Integer generar_id() {
        return llantas.length + 1;
    }

}
