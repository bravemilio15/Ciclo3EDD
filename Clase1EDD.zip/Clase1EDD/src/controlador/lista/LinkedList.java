/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador.lista;

import controlador.lista.Exception.VacioException;

/**
 *
 * @author emilio
 */
public class LinkedList<E> {
    
    private Nodo<E> head;
    private Nodo<E> last;
    private Integer size;
    
    public LinkedList() {
        head = null;
        last = null;
        size = 0;
    }
    
    public Integer getSize() {
        return size;
    }
    
    public void setSize(Integer size) {
        this.size = size;
    }
    
    public Boolean isEmpty() {
        return head == null || size == 0;
    }
    
    protected void addFirst(E data) {
        if (isEmpty()) {
            Nodo<E> aux = new Nodo<>(data, null);
            head = aux;
            last = aux;
        } else {
            Nodo<E> headOld = head;
            Nodo<E> aux = new Nodo<>(data, headOld);
            head = aux;
        }
        size++;
    }
    
    protected void addLast(E data) {
        if (isEmpty()) {
            addFirst(data);
        } else {
            Nodo<E> aux = new Nodo<>(data, null);
            last.setNext(aux);
            last = aux;
            size++;
        }
        
    }
    
    public void add(E data) {
        addLast(data);
    }
    
    public void add(E data, Integer post) throws VacioException {
        if (post == 0) {
            addFirst(data);
        } else if (post.intValue() == size.intValue()) {
            addLast(data);
        } else {
            Nodo<E> search_preview = getNode(post - 1);
            Nodo<E> search = getNode(post);
            Nodo<E> aux = new Nodo<>(data, search);
            search_preview.setNext(aux);
            size++;
            
        }
    }
    
    public Nodo<E> getNode(Integer post) throws VacioException {
        if (isEmpty()) {
            throw new VacioException("Lista Esta Vacia ");
        } else if (post < 0 || post > size) {
            throw new IndexOutOfBoundsException("Error esta fuera de los limites de la lista");
        } else if (post == 0) {
            return head;
        } else if (post == (size - 1)) {
            return last;
        } else {
            Nodo<E> search = head;
            Integer cont = 0;
            while (cont < post) {
                cont++;
                search = search.getNext();
            }
            return search;
        }
    }
    
    public String print() {
        StringBuilder sb = new StringBuilder();
        if (isEmpty()) {
            sb.append("Lista Vacia");
        } else {
            Nodo<E> aux = head;
            while (aux != null) {
                sb.append(aux.getData().toString()).append("\n");
                aux = aux.getNext();
            }
        }
        return sb.toString();
    }
    
    public static void main(String[] args) {
        LinkedList<Integer> numerics = new LinkedList<>();
        for (int i = 0; i < 10; i++) {
            Integer aux = (int) (Math.random() * 1000);
            numerics.add(aux);
        }
        
        System.out.println(numerics.print());
        System.out.println("Tamaño de la lista: " + numerics.getSize());
        try {
            numerics.add(1, 8);
            System.out.println("---------------------------------------------");
            System.out.println(numerics.print());
            System.out.println(numerics.getNode(10).getData().toString());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
}
