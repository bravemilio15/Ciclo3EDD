/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author emilio
 */
public class Cuenta {
    private Integer id;
    private String usuario;
    private String clave;
    private Boolean estado;
    private Integer id_Persona;

    public Cuenta() {
    }

    public Cuenta(Integer id, String usuario, String clave, boolean estado, Integer id_Persona) {
        this.id = id;
        this.usuario = usuario;
        this.clave = clave;
        this.estado = estado;
        this.id_Persona = id_Persona;
    }
    
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public Integer getId_Persona() {
        return id_Persona;
    }

    public void setId_Persona(Integer id_Persona) {
        this.id_Persona = id_Persona;
    }
    
    
    
}
